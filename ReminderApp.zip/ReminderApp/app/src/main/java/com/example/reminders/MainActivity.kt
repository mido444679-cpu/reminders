package com.example.reminders

import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.ensureChannel(this)
        setContent {
            MaterialTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    App()
                }
            }
        }
    }
}

private fun describe(r: Reminder): String =
    if (r.type == Reminder.INTERVAL) {
        val m = r.intervalMinutes
        if (m % 60 == 0) "كل ${m / 60} ساعة" else "كل $m دقيقة"
    } else {
        "يوميا: " + r.times.sorted().joinToString("، ")
    }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val items = remember { mutableStateListOf<Reminder>().apply { addAll(Store.load(ctx)) } }
    var editing by remember { mutableStateOf<Reminder?>(null) }
    var showDialog by remember { mutableStateOf(false) }
    var exactOk by remember { mutableStateOf(Scheduler.canScheduleExact(ctx)) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    fun persist() {
        Store.save(ctx, items.toList())
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("تذكيراتي") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { editing = null; showDialog = true }) { Text("+") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            if (!exactOk) {
                Card(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("عشان التذكيرات اليومية تيجي في الدقيقة بالظبط، فعّل إذن «المنبهات والتذكيرات».")
                        TextButton(onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                            }
                        }) { Text("فتح الإعدادات") }
                        TextButton(onClick = { exactOk = Scheduler.canScheduleExact(ctx) }) { Text("تحديث الحالة") }
                    }
                }
            }
            if (items.isEmpty()) {
                Text("مفيش تذكيرات. اضغط + لإضافة تذكير.")
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items, key = { it.id }) { r ->
                    Card(Modifier.fillMaxWidth().clickable { editing = r; showDialog = true }) {
                        Row(
                            Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(r.message, style = MaterialTheme.typography.titleMedium)
                                Text(describe(r), style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = r.enabled, onCheckedChange = { on ->
                                val idx = items.indexOfFirst { it.id == r.id }
                                val upd = r.copy(enabled = on)
                                items[idx] = upd
                                persist()
                                Scheduler.schedule(ctx, upd)
                            })
                            TextButton(onClick = {
                                Scheduler.cancel(ctx, r)
                                items.removeAll { it.id == r.id }
                                persist()
                            }) { Text("حذف") }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        EditDialog(
            initial = editing,
            onDismiss = { showDialog = false },
            onSave = { msg, type, minutes, times ->
                val old = editing
                val r = Reminder(
                    id = old?.id ?: Store.newId(ctx),
                    message = msg,
                    type = type,
                    intervalMinutes = minutes,
                    times = times,
                    enabled = old?.enabled ?: true
                )
                if (old == null) items.add(r) else items[items.indexOfFirst { it.id == old.id }] = r
                persist()
                Scheduler.schedule(ctx, r)
                showDialog = false
            }
        )
    }
}

@Composable
fun EditDialog(
    initial: Reminder?,
    onDismiss: () -> Unit,
    onSave: (String, Int, Int, List<String>) -> Unit
) {
    val ctx = LocalContext.current
    var message by remember { mutableStateOf(initial?.message ?: "") }
    var type by remember { mutableIntStateOf(initial?.type ?: Reminder.INTERVAL) }
    var hours by remember {
        mutableStateOf(((initial?.intervalMinutes ?: 60) / 60.0).toString().removeSuffix(".0"))
    }
    val times = remember { mutableStateListOf<String>().apply { initial?.times?.let { addAll(it) } } }

    val hoursVal = hours.toDoubleOrNull()
    val valid = message.isNotBlank() &&
            (if (type == Reminder.INTERVAL) hoursVal != null && hoursVal > 0 else times.isNotEmpty())

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "تذكير جديد" else "تعديل التذكير") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = message, onValueChange = { message = it },
                    label = { Text("نص الرسالة") }, modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = type == Reminder.INTERVAL, onClick = { type = Reminder.INTERVAL })
                    Text("كل فترة")
                    Spacer(Modifier.width(16.dp))
                    RadioButton(selected = type == Reminder.DAILY, onClick = { type = Reminder.DAILY })
                    Text("أوقات يومية")
                }
                if (type == Reminder.INTERVAL) {
                    OutlinedTextField(
                        value = hours, onValueChange = { hours = it },
                        label = { Text("كل كم ساعة؟ (مثلا 2 أو 0.5)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    times.sorted().forEach { t ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(t, Modifier.weight(1f))
                            TextButton(onClick = { times.remove(t) }) { Text("إزالة") }
                        }
                    }
                    OutlinedButton(onClick = {
                        TimePickerDialog(ctx, { _, h, m ->
                            val s = String.format(Locale.US, "%02d:%02d", h, m)
                            if (s !in times) times.add(s)
                        }, 8, 0, true).show()
                    }) { Text("إضافة وقت") }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = {
                val minutes = ((hoursVal ?: 1.0) * 60).toInt().coerceAtLeast(15)
                onSave(message.trim(), type, minutes, times.sorted())
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
