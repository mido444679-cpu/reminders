package com.example.reminders

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.ensureChannel(this)
        setContent {
            var themeMode by remember { mutableIntStateOf(Store.getTheme(this@MainActivity)) }
            val dark = when (themeMode) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    App(themeMode) { mode ->
                        themeMode = mode
                        Store.setTheme(this@MainActivity, mode)
                    }
                }
            }
        }
    }
}

private val fmtDateTime = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US)
private val fmtClock = SimpleDateFormat("HH:mm", Locale.US)

private fun describe(r: Reminder): String = when (r.type) {
    Reminder.ONCE -> {
        val done = if (r.startAt < System.currentTimeMillis()) " (تم)" else ""
        "مرة واحدة: ${fmtDateTime.format(Date(r.startAt))}$done"
    }
    Reminder.INTERVAL -> {
        val m = r.intervalMinutes
        val base = if (m % 60 == 0) "كل ${m / 60} ساعة" else "كل $m دقيقة"
        if (r.startAt > 0L) "$base، تبدأ من ${fmtClock.format(Date(r.startAt))}" else base
    }
    else -> "يوميا: " + r.times.sorted().joinToString("، ")
}

// اختيار تاريخ ثم وقت
private fun pickDateTime(ctx: Context, onPicked: (Long) -> Unit) {
    val now = Calendar.getInstance()
    val dlg = DatePickerDialog(ctx, { _, y, m, d ->
        TimePickerDialog(ctx, { _, h, min ->
            val c = Calendar.getInstance().apply {
                set(y, m, d, h, min, 0)
                set(Calendar.MILLISECOND, 0)
            }
            onPicked(c.timeInMillis)
        }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
    }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH))
    dlg.datePicker.minDate = System.currentTimeMillis() - 1000
    dlg.show()
}

// اختيار ساعة فقط (اليوم)
private fun pickClock(ctx: Context, onPicked: (Long) -> Unit) {
    val now = Calendar.getInstance()
    TimePickerDialog(ctx, { _, h, min ->
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h)
            set(Calendar.MINUTE, min)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        onPicked(c.timeInMillis)
    }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(themeMode: Int, onThemeChange: (Int) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val items = remember { mutableStateListOf<Reminder>().apply { addAll(Store.load(ctx)) } }
    var editing by remember { mutableStateOf<Reminder?>(null) }
    var showDialog by remember { mutableStateOf(false) }
    var prefillTitle by remember { mutableStateOf("") }
    var prefillMsg by remember { mutableStateOf("") }
    val notes = remember { mutableStateListOf<Note>().apply { addAll(Store.loadNotes(ctx)) } }
    var tab by remember { mutableIntStateOf(0) }
    var noteEditing by remember { mutableStateOf<Note?>(null) }
    var noteEditorOpen by remember { mutableStateOf(false) }
    var exactOk by remember { mutableStateOf(Scheduler.canScheduleExact(ctx)) }
    var reliable by remember { mutableStateOf(Store.isReliable(ctx)) }
    val isXiaomi = Build.MANUFACTURER.lowercase(Locale.ROOT).let {
        it.contains("xiaomi") || it.contains("redmi") || it.contains("poco")
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    fun persist() {
        Store.save(ctx, items.toList())
    }

    // حفظ مذكرة: فاضية تماما = ما تتحفظش (وتتحذف لو كانت موجودة)، بدون تغيير = ما يتغيرش وقتها
    fun saveNote(old: Note?, title: String, body: String) {
        val t = title.trim()
        val b = body.trim()
        if (t.isEmpty() && b.isEmpty()) {
            if (old != null) {
                notes.removeAll { it.id == old.id }
                Store.saveNotes(ctx, notes.toList())
            }
            return
        }
        if (old != null && old.title == t && old.body == b) return
        val upd = Note(old?.id ?: Store.newNoteId(ctx), t, b, System.currentTimeMillis())
        if (old != null) notes.removeAll { it.id == old.id }
        notes.add(0, upd)
        Store.saveNotes(ctx, notes.toList())
    }

    fun currentSoundName(): String {
        val s = Store.getSound(ctx) ?: return "نغمة التطبيق"
        return RingtoneManager.getRingtone(ctx, Uri.parse(s))?.getTitle(ctx) ?: "نغمة مخصصة"
    }

    var soundName by remember { mutableStateOf(currentSoundName()) }
    val soundLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val data = res.data
            @Suppress("DEPRECATION")
            val picked: Uri? = if (Build.VERSION.SDK_INT >= 33)
                data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            else
                data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            Store.setSound(ctx, picked?.toString())
            Notifier.ensureChannel(ctx)
            soundName = currentSoundName()
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use {
                    it.write(Store.exportBackup(items.toList(), notes.toList()).toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(ctx, "تم حفظ النسخة الاحتياطية", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "تعذر حفظ الملف", Toast.LENGTH_SHORT).show()
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val raw = ctx.contentResolver.openInputStream(uri)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                val backup = raw?.let { Store.parseBackup(it) }
                if (backup == null) {
                    Toast.makeText(ctx, "الملف ده مش نسخة احتياطية صالحة", Toast.LENGTH_LONG).show()
                } else {
                    val list = backup.reminders
                    items.forEach { Scheduler.cancel(ctx, it) }
                    items.clear()
                    items.addAll(list)
                    Store.ensureNextIdAbove(ctx, list)
                    persist()
                    list.forEach { Scheduler.schedule(ctx, it) }
                    backup.notes?.let { n ->
                        notes.clear()
                        notes.addAll(n)
                        Store.ensureNextNoteIdAbove(ctx, n)
                        Store.saveNotes(ctx, n)
                    }
                    val msg = "تم استرجاع ${list.size} تذكير" +
                            (backup.notes?.let { " و${it.size} مذكرة" } ?: "")
                    Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(ctx, "تعذر قراءة الملف", Toast.LENGTH_SHORT).show()
            }
        }
    }

    if (noteEditorOpen) {
        NoteEditor(
            initial = noteEditing,
            onClose = { t, b ->
                saveNote(noteEditing, t, b)
                noteEditorOpen = false
                noteEditing = null
            },
            onDelete = {
                noteEditing?.let { n ->
                    notes.removeAll { it.id == n.id }
                    Store.saveNotes(ctx, notes.toList())
                }
                noteEditorOpen = false
                noteEditing = null
            },
            onMakeReminder = { t, b ->
                saveNote(noteEditing, t, b)
                // لو المذكرة عنوان بس، العنوان يبقى نص التذكير
                prefillMsg = b.trim().ifBlank { t.trim() }
                prefillTitle = if (b.isBlank()) "" else t.trim()
                noteEditorOpen = false
                noteEditing = null
                tab = 0
                editing = null
                showDialog = true
            }
        )
    } else ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Column(
                    Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("الإعدادات", style = MaterialTheme.typography.titleLarge)
                    HorizontalDivider()

                    Text("المظهر", style = MaterialTheme.typography.titleSmall)
                    listOf(0 to "تلقائي (حسب الجهاز)", 1 to "فاتح", 2 to "داكن").forEach { (m, label) ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onThemeChange(m) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = themeMode == m, onClick = { onThemeChange(m) })
                            Text(label)
                        }
                    }
                    HorizontalDivider()

                    Text("نغمة التنبيه", style = MaterialTheme.typography.titleSmall)
                    Text(soundName)
                    Row {
                        TextButton(onClick = {
                            val cur = Store.getSound(ctx)?.let { Uri.parse(it) }
                            soundLauncher.launch(Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "اختر نغمة التنبيه")
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, cur)
                            })
                        }) { Text("تغيير") }
                        TextButton(onClick = {
                            Notifier.show(ctx, Reminder(0, "هذا اختبار للنغمة", Reminder.INTERVAL))
                        }) { Text("جرّب") }
                        TextButton(onClick = {
                            Store.setSound(ctx, null)
                            Notifier.ensureChannel(ctx)
                            soundName = currentSoundName()
                        }) { Text("نغمة التطبيق") }
                    }
                    HorizontalDivider()

                    Text("النسخة الاحتياطية", style = MaterialTheme.typography.titleSmall)
                    Text("بتشمل التذكيرات والمذكرات. الاسترجاع بيستبدل الحاليين.", style = MaterialTheme.typography.bodySmall)
                    Row {
                        TextButton(onClick = { exportLauncher.launch("reminders-backup.json") }) {
                            Text("حفظ نسخة")
                        }
                        TextButton(onClick = { importLauncher.launch(arrayOf("*/*")) }) {
                            Text("استرجاع")
                        }
                    }
                    HorizontalDivider()

                    Text("دقة المواعيد", style = MaterialTheme.typography.titleSmall)
                    if (exactOk) {
                        Text("إذن المنبهات والتذكيرات مفعّل، فالتذكيرات بتيجي في وقتها بالظبط.")
                    } else {
                        Text("إذن «المنبهات والتذكيرات» مش مفعّل، فالتذكيرات ممكن تتأخر شوية.")
                        Row {
                            TextButton(onClick = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                    ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                                }
                            }) { Text("فتح الإعدادات") }
                            TextButton(onClick = { exactOk = Scheduler.canScheduleExact(ctx) }) {
                                Text("تحديث الحالة")
                            }
                        }
                    }
                    HorizontalDivider()

                    Text("لو التنبيه بيتأخر", style = MaterialTheme.typography.titleSmall)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("الوضع الموثوق (بيظهر أيقونة منبه صغيرة)", Modifier.weight(1f))
                        Switch(checked = reliable, onCheckedChange = { on ->
                            reliable = on
                            Store.setReliable(ctx, on)
                            items.forEach { Scheduler.schedule(ctx, it) }
                        })
                    }
                    Text(
                        "لو التنبيه بيوصل بس لما تفتح التطبيق، سمّح للتطبيق بالعمل في الخلفية وفعّل التشغيل التلقائي.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Row {
                        TextButton(onClick = {
                            runCatching {
                                ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                            }
                        }) { Text("إعدادات البطارية") }
                        TextButton(onClick = {
                            runCatching {
                                ctx.startActivity(
                                    Intent(
                                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                        Uri.parse("package:${ctx.packageName}")
                                    )
                                )
                            }
                        }) { Text("إعدادات التطبيق") }
                    }
                    if (isXiaomi) {
                        TextButton(onClick = {
                            runCatching {
                                ctx.startActivity(
                                    Intent().setComponent(
                                        ComponentName(
                                            "com.miui.securitycenter",
                                            "com.miui.permcenter.autostart.AutoStartManagementActivity"
                                        )
                                    )
                                )
                            }
                        }) { Text("التشغيل التلقائي (شاومي)") }
                    }
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (tab == 0) "تذكيراتي" else "مذكراتي") },
                    navigationIcon = {
                        TextButton(onClick = { scope.launch { drawerState.open() } }) {
                            Text("☰", style = MaterialTheme.typography.titleLarge)
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = tab == 0, onClick = { tab = 0 },
                        icon = { Text("🔔") }, label = { Text("التذكيرات") }
                    )
                    NavigationBarItem(
                        selected = tab == 1, onClick = { tab = 1 },
                        icon = { Text("📝") }, label = { Text("المذكرات") }
                    )
                }
            },
            floatingActionButton = {
                ExtendedFloatingActionButton(onClick = {
                    if (tab == 0) {
                        editing = null
                        prefillTitle = ""
                        prefillMsg = ""
                        showDialog = true
                    } else {
                        noteEditing = null
                        noteEditorOpen = true
                    }
                }) {
                    Text(if (tab == 0) "+ تذكير جديد" else "+ مذكرة جديدة")
                }
            }
        ) { pad ->
            if (tab == 1) {
                NotesList(pad, notes) { n -> noteEditing = n; noteEditorOpen = true }
            } else Column(Modifier.padding(pad).padding(horizontal = 16.dp)) {
                if (items.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("مفيش تذكيرات لسه.\nاضغط «+ تذكير جديد» لإضافة أول تذكير.")
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(top = 8.dp, bottom = 96.dp)
                    ) {
                        items(items, key = { it.id }) { r ->
                            Card(Modifier.fillMaxWidth().clickable { editing = r; showDialog = true }) {
                                Row(
                                    Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            r.title.ifBlank { r.message },
                                            style = MaterialTheme.typography.titleMedium
                                        )
                                        if (r.title.isNotBlank()) {
                                            Text(r.message, style = MaterialTheme.typography.bodyMedium)
                                        }
                                        Text(describe(r), style = MaterialTheme.typography.bodySmall)
                                    }
                                    Switch(checked = r.enabled, onCheckedChange = { on ->
                                        val idx = items.indexOfFirst { it.id == r.id }
                                        val upd = r.copy(enabled = on)
                                        items[idx] = upd
                                        persist()
                                        Scheduler.schedule(ctx, upd)
                                    })
                                    TextButton(onClick = {
                                        Scheduler.cancel(ctx, r)
                                        items.removeAll { it.id == r.id }
                                        persist()
                                    }) { Text("حذف") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        EditDialog(
            initial = editing,
            prefillTitle = prefillTitle,
            prefillMsg = prefillMsg,
            onDismiss = { showDialog = false; prefillTitle = ""; prefillMsg = "" },
            onSave = { title, msg, type, minutes, times, startAt ->
                val old = editing
                val r = Reminder(
                    id = old?.id ?: Store.newId(ctx),
                    message = msg,
                    type = type,
                    intervalMinutes = minutes,
                    times = times,
                    enabled = if (type == Reminder.ONCE) true else (old?.enabled ?: true),
                    startAt = startAt,
                    title = title
                )
                if (old == null) items.add(r) else items[items.indexOfFirst { it.id == old.id }] = r
                persist()
                Scheduler.schedule(ctx, r)
                showDialog = false
                prefillTitle = ""
                prefillMsg = ""
            }
        )
    }
}

@Composable
fun EditDialog(
    initial: Reminder?,
    prefillTitle: String = "",
    prefillMsg: String = "",
    onDismiss: () -> Unit,
    onSave: (String, String, Int, Int, List<String>, Long) -> Unit
) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf(initial?.title ?: prefillTitle) }
    var message by remember { mutableStateOf(initial?.message ?: prefillMsg) }
    var type by remember { mutableIntStateOf(initial?.type ?: Reminder.ONCE) }
    val initMinutes = initial?.intervalMinutes ?: 60
    var unitMinutes by remember { mutableStateOf(initMinutes % 60 != 0) }
    var amount by remember {
        mutableStateOf((if (initMinutes % 60 != 0) initMinutes else initMinutes / 60).toString())
    }
    var afterMin by remember { mutableStateOf("") }
    val times = remember { mutableStateListOf<String>().apply { initial?.times?.let { addAll(it) } } }
    var onceAt by remember {
        mutableLongStateOf(initial?.takeIf { it.type == Reminder.ONCE }?.startAt ?: 0L)
    }
    var startAt by remember {
        mutableLongStateOf(initial?.takeIf { it.type == Reminder.INTERVAL }?.startAt ?: 0L)
    }

    val amountVal = amount.toDoubleOrNull()
    val afterVal = afterMin.toDoubleOrNull()
    val valid = message.isNotBlank() && when (type) {
        Reminder.ONCE -> onceAt > System.currentTimeMillis() || (afterVal != null && afterVal > 0)
        Reminder.INTERVAL -> amountVal != null && amountVal > 0
        else -> times.isNotEmpty()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "تذكير جديد" else "تعديل التذكير") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = title, onValueChange = { title = it },
                    label = { Text("اسم التذكير (اختياري)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = message, onValueChange = { message = it },
                    label = { Text("نص الرسالة") }, modifier = Modifier.fillMaxWidth()
                )
                Text("التكرار", style = MaterialTheme.typography.titleSmall)
                listOf(
                    Reminder.ONCE to "مرة واحدة (بدون تكرار)",
                    Reminder.INTERVAL to "كل فترة (كل س ساعة)",
                    Reminder.DAILY to "يوميا في أوقات محددة"
                ).forEach { (t, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { type = t },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = type == t, onClick = { type = t })
                        Text(label)
                    }
                }
                when (type) {
                    Reminder.ONCE -> {
                        Text(
                            if (afterVal != null && afterVal > 0)
                                "سيتم التذكير بعد ${afterVal.toInt()} دقيقة من الحفظ"
                            else if (onceAt > 0L)
                                "الموعد: ${fmtDateTime.format(Date(onceAt))}"
                            else "لم يتم اختيار موعد"
                        )
                        OutlinedButton(onClick = { pickDateTime(ctx) { onceAt = it; afterMin = "" } }) {
                            Text("اختيار التاريخ والوقت")
                        }
                        OutlinedTextField(
                            value = afterMin, onValueChange = { afterMin = it },
                            label = { Text("أو بعد كم دقيقة من الآن؟") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Reminder.INTERVAL -> {
                        OutlinedTextField(
                            value = amount, onValueChange = { amount = it },
                            label = { Text("كل كام؟") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = unitMinutes, onClick = { unitMinutes = true })
                            Text("دقيقة")
                            Spacer(Modifier.width(16.dp))
                            RadioButton(selected = !unitMinutes, onClick = { unitMinutes = false })
                            Text("ساعة")
                        }
                        if (unitMinutes && (amountVal ?: 15.0) < 15) {
                            Text(
                                "تنبيه: الفترات القصيرة جدا بتستهلك بطارية أكتر، والنظام ممكن يأخر التنبيه لو الموبايل في وضع السكون.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Text(
                            if (startAt > 0L) "تبدأ من الساعة ${fmtClock.format(Date(startAt))}"
                            else "تبدأ من الآن"
                        )
                        Row {
                            OutlinedButton(onClick = { pickClock(ctx) { startAt = it } }) {
                                Text("تحديد ساعة البدء")
                            }
                            if (startAt > 0L) {
                                TextButton(onClick = { startAt = 0L }) { Text("مسح") }
                            }
                        }
                    }
                    else -> {
                        times.sorted().forEach { t ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(t, Modifier.weight(1f))
                                TextButton(onClick = { times.remove(t) }) { Text("إزالة") }
                            }
                        }
                        OutlinedButton(onClick = {
                            TimePickerDialog(ctx, { _, h, m ->
                                val s = String.format(Locale.US, "%02d:%02d", h, m)
                                if (s !in times) times.add(s)
                            }, 8, 0, true).show()
                        }) { Text("إضافة وقت") }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = {
                val minutes = ((amountVal ?: 1.0) * (if (unitMinutes) 1 else 60)).toInt().coerceAtLeast(1)
                val start = when (type) {
                    Reminder.ONCE ->
                        if (afterVal != null && afterVal > 0)
                            System.currentTimeMillis() + (afterVal * 60_000).toLong()
                        else onceAt
                    Reminder.INTERVAL -> startAt
                    else -> 0L
                }
                onSave(title.trim(), message.trim(), type, minutes, times.sorted(), start)
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun NotesList(pad: PaddingValues, notes: List<Note>, onOpen: (Note) -> Unit) {
    Column(Modifier.padding(pad).padding(horizontal = 16.dp)) {
        if (notes.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("مفيش مذكرات لسه.\nاضغط «+ مذكرة جديدة» لكتابة أول مذكرة.")
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 96.dp)
            ) {
                items(notes, key = { it.id }) { n ->
                    Card(Modifier.fillMaxWidth().clickable { onOpen(n) }) {
                        Column(Modifier.padding(12.dp).fillMaxWidth()) {
                            Text(
                                n.title.ifBlank { "بدون عنوان" },
                                style = MaterialTheme.typography.titleMedium
                            )
                            if (n.body.isNotBlank()) {
                                Text(
                                    n.body,
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 3,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Text(
                                fmtDateTime.format(Date(n.updatedAt)),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditor(
    initial: Note?,
    onClose: (String, String) -> Unit,
    onDelete: () -> Unit,
    onMakeReminder: (String, String) -> Unit
) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var body by remember { mutableStateOf(initial?.body ?: "") }
    var confirmDelete by remember { mutableStateOf(false) }

    // زر الرجوع بيحفظ المذكرة تلقائيا
    BackHandler { onClose(title, body) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (initial == null) "مذكرة جديدة" else "المذكرة") },
                navigationIcon = {
                    TextButton(onClick = { onClose(title, body) }) {
                        Text("→", style = MaterialTheme.typography.titleLarge)
                    }
                },
                actions = {
                    if (initial != null) {
                        TextButton(onClick = { confirmDelete = true }) { Text("حذف") }
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = title, onValueChange = { title = it },
                label = { Text("العنوان (اختياري)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = body, onValueChange = { body = it },
                label = { Text("اكتب مذكرتك هنا") },
                modifier = Modifier.fillMaxWidth().weight(1f)
            )
            TextButton(
                enabled = title.isNotBlank() || body.isNotBlank(),
                onClick = { onMakeReminder(title, body) }
            ) { Text("إنشاء تذكير من المذكرة") }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("حذف المذكرة؟") },
            text = { Text("مش هتقدر ترجعها بعد الحذف.") },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } }
        )
    }
}
