package com.example.reminders

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.ensureChannel(this)
        setContent {
            MaterialTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    App()
                }
            }
        }
    }
}

private val fmtDateTime = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US)
private val fmtClock = SimpleDateFormat("HH:mm", Locale.US)

private fun describe(r: Reminder): String = when (r.type) {
    Reminder.ONCE -> {
        val done = if (r.startAt < System.currentTimeMillis()) " (تم)" else ""
        "مرة واحدة: ${fmtDateTime.format(Date(r.startAt))}$done"
    }
    Reminder.INTERVAL -> {
        val m = r.intervalMinutes
        val base = if (m % 60 == 0) "كل ${m / 60} ساعة" else "كل $m دقيقة"
        if (r.startAt > 0L) "$base، تبدأ من ${fmtClock.format(Date(r.startAt))}" else base
    }
    else -> "يوميا: " + r.times.sorted().joinToString("، ")
}

// اختيار تاريخ ثم وقت
private fun pickDateTime(ctx: Context, onPicked: (Long) -> Unit) {
    val now = Calendar.getInstance()
    val dlg = DatePickerDialog(ctx, { _, y, m, d ->
        TimePickerDialog(ctx, { _, h, min ->
            val c = Calendar.getInstance().apply {
                set(y, m, d, h, min, 0)
                set(Calendar.MILLISECOND, 0)
            }
            onPicked(c.timeInMillis)
        }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
    }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH))
    dlg.datePicker.minDate = System.currentTimeMillis() - 1000
    dlg.show()
}

// اختيار ساعة فقط (اليوم)
private fun pickClock(ctx: Context, onPicked: (Long) -> Unit) {
    val now = Calendar.getInstance()
    TimePickerDialog(ctx, { _, h, min ->
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h)
            set(Calendar.MINUTE, min)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        onPicked(c.timeInMillis)
    }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).show()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val items = remember { mutableStateListOf<Reminder>().apply { addAll(Store.load(ctx)) } }
    var editing by remember { mutableStateOf<Reminder?>(null) }
    var showDialog by remember { mutableStateOf(false) }
    var exactOk by remember { mutableStateOf(Scheduler.canScheduleExact(ctx)) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    fun persist() {
        Store.save(ctx, items.toList())
    }

    fun currentSoundName(): String {
        val s = Store.getSound(ctx) ?: return "نغمة التطبيق"
        return RingtoneManager.getRingtone(ctx, Uri.parse(s))?.getTitle(ctx) ?: "نغمة مخصصة"
    }

    var soundName by remember { mutableStateOf(currentSoundName()) }
    val soundLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val data = res.data
            @Suppress("DEPRECATION")
            val picked: Uri? = if (Build.VERSION.SDK_INT >= 33)
                data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            else
                data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            Store.setSound(ctx, picked?.toString())
            Notifier.ensureChannel(ctx)
            soundName = currentSoundName()
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use {
                    it.write(Store.exportBackup(items.toList()).toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(ctx, "تم حفظ النسخة الاحتياطية", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "تعذر حفظ الملف", Toast.LENGTH_SHORT).show()
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val raw = ctx.contentResolver.openInputStream(uri)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                val list = raw?.let { Store.parseBackup(it) }
                if (list == null) {
                    Toast.makeText(ctx, "الملف ده مش نسخة احتياطية صالحة", Toast.LENGTH_LONG).show()
                } else {
                    items.forEach { Scheduler.cancel(ctx, it) }
                    items.clear()
                    items.addAll(list)
                    Store.ensureNextIdAbove(ctx, list)
                    persist()
                    list.forEach { Scheduler.schedule(ctx, it) }
                    Toast.makeText(ctx, "تم استرجاع ${list.size} تذكير", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(ctx, "تعذر قراءة الملف", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("تذكيراتي") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { editing = null; showDialog = true }) { Text("+") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            Card(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("نغمة التنبيه: $soundName")
                    Row {
                        TextButton(onClick = {
                            val cur = Store.getSound(ctx)?.let { Uri.parse(it) }
                            soundLauncher.launch(Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "اختر نغمة التنبيه")
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, cur)
                            })
                        }) { Text("تغيير") }
                        TextButton(onClick = {
                            Notifier.show(ctx, Reminder(0, "هذا اختبار للنغمة", Reminder.INTERVAL))
                        }) { Text("جرّب") }
                        TextButton(onClick = {
                            Store.setSound(ctx, null)
                            Notifier.ensureChannel(ctx)
                            soundName = currentSoundName()
                        }) { Text("نغمة التطبيق") }
                    }
                }
            }
            Card(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("النسخة الاحتياطية (الاسترجاع بيستبدل التذكيرات الحالية)")
                    Row {
                        TextButton(onClick = { exportLauncher.launch("reminders-backup.json") }) {
                            Text("حفظ نسخة")
                        }
                        TextButton(onClick = { importLauncher.launch(arrayOf("*/*")) }) {
                            Text("استرجاع")
                        }
                    }
                }
            }
            if (!exactOk) {
                Card(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("عشان التذكيرات تيجي في الدقيقة بالظبط، فعّل إذن «المنبهات والتذكيرات».")
                        TextButton(onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
                            }
                        }) { Text("فتح الإعدادات") }
                        TextButton(onClick = { exactOk = Scheduler.canScheduleExact(ctx) }) { Text("تحديث الحالة") }
                    }
                }
            }
            if (items.isEmpty()) {
                Text("مفيش تذكيرات. اضغط + لإضافة تذكير.")
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items, key = { it.id }) { r ->
                    Card(Modifier.fillMaxWidth().clickable { editing = r; showDialog = true }) {
                        Row(
                            Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(r.message, style = MaterialTheme.typography.titleMedium)
                                Text(describe(r), style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = r.enabled, onCheckedChange = { on ->
                                val idx = items.indexOfFirst { it.id == r.id }
                                val upd = r.copy(enabled = on)
                                items[idx] = upd
                                persist()
                                Scheduler.schedule(ctx, upd)
                            })
                            TextButton(onClick = {
                                Scheduler.cancel(ctx, r)
                                items.removeAll { it.id == r.id }
                                persist()
                            }) { Text("حذف") }
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        EditDialog(
            initial = editing,
            onDismiss = { showDialog = false },
            onSave = { msg, type, minutes, times, startAt ->
                val old = editing
                val r = Reminder(
                    id = old?.id ?: Store.newId(ctx),
                    message = msg,
                    type = type,
                    intervalMinutes = minutes,
                    times = times,
                    enabled = if (type == Reminder.ONCE) true else (old?.enabled ?: true),
                    startAt = startAt
                )
                if (old == null) items.add(r) else items[items.indexOfFirst { it.id == old.id }] = r
                persist()
                Scheduler.schedule(ctx, r)
                showDialog = false
            }
        )
    }
}

@Composable
fun EditDialog(
    initial: Reminder?,
    onDismiss: () -> Unit,
    onSave: (String, Int, Int, List<String>, Long) -> Unit
) {
    val ctx = LocalContext.current
    var message by remember { mutableStateOf(initial?.message ?: "") }
    var type by remember { mutableIntStateOf(initial?.type ?: Reminder.ONCE) }
    val initMinutes = initial?.intervalMinutes ?: 60
    var unitMinutes by remember { mutableStateOf(initMinutes % 60 != 0) }
    var amount by remember {
        mutableStateOf((if (initMinutes % 60 != 0) initMinutes else initMinutes / 60).toString())
    }
    var afterMin by remember { mutableStateOf("") }
    val times = remember { mutableStateListOf<String>().apply { initial?.times?.let { addAll(it) } } }
    var onceAt by remember {
        mutableLongStateOf(initial?.takeIf { it.type == Reminder.ONCE }?.startAt ?: 0L)
    }
    var startAt by remember {
        mutableLongStateOf(initial?.takeIf { it.type == Reminder.INTERVAL }?.startAt ?: 0L)
    }

    val amountVal = amount.toDoubleOrNull()
    val afterVal = afterMin.toDoubleOrNull()
    val valid = message.isNotBlank() && when (type) {
        Reminder.ONCE -> onceAt > System.currentTimeMillis() || (afterVal != null && afterVal > 0)
        Reminder.INTERVAL -> amountVal != null && amountVal > 0
        else -> times.isNotEmpty()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "تذكير جديد" else "تعديل التذكير") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = message, onValueChange = { message = it },
                    label = { Text("نص الرسالة") }, modifier = Modifier.fillMaxWidth()
                )
                Text("التكرار", style = MaterialTheme.typography.titleSmall)
                listOf(
                    Reminder.ONCE to "مرة واحدة (بدون تكرار)",
                    Reminder.INTERVAL to "كل فترة (كل س ساعة)",
                    Reminder.DAILY to "يوميا في أوقات محددة"
                ).forEach { (t, label) ->
                    Row(
                        Modifier.fillMaxWidth().clickable { type = t },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = type == t, onClick = { type = t })
                        Text(label)
                    }
                }
                when (type) {
                    Reminder.ONCE -> {
                        Text(
                            if (afterVal != null && afterVal > 0)
                                "سيتم التذكير بعد ${afterVal.toInt()} دقيقة من الحفظ"
                            else if (onceAt > 0L)
                                "الموعد: ${fmtDateTime.format(Date(onceAt))}"
                            else "لم يتم اختيار موعد"
                        )
                        OutlinedButton(onClick = { pickDateTime(ctx) { onceAt = it; afterMin = "" } }) {
                            Text("اختيار التاريخ والوقت")
                        }
                        OutlinedTextField(
                            value = afterMin, onValueChange = { afterMin = it },
                            label = { Text("أو بعد كم دقيقة من الآن؟") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Reminder.INTERVAL -> {
                        OutlinedTextField(
                            value = amount, onValueChange = { amount = it },
                            label = { Text("كل كام؟") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = unitMinutes, onClick = { unitMinutes = true })
                            Text("دقيقة")
                            Spacer(Modifier.width(16.dp))
                            RadioButton(selected = !unitMinutes, onClick = { unitMinutes = false })
                            Text("ساعة")
                        }
                        if (unitMinutes && (amountVal ?: 15.0) < 15) {
                            Text(
                                "تنبيه: الفترات القصيرة جدا بتستهلك بطارية أكتر، والنظام ممكن يأخر التنبيه لو الموبايل في وضع السكون.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Text(
                            if (startAt > 0L) "تبدأ من الساعة ${fmtClock.format(Date(startAt))}"
                            else "تبدأ من الآن"
                        )
                        Row {
                            OutlinedButton(onClick = { pickClock(ctx) { startAt = it } }) {
                                Text("تحديد ساعة البدء")
                            }
                            if (startAt > 0L) {
                                TextButton(onClick = { startAt = 0L }) { Text("مسح") }
                            }
                        }
                    }
                    else -> {
                        times.sorted().forEach { t ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(t, Modifier.weight(1f))
                                TextButton(onClick = { times.remove(t) }) { Text("إزالة") }
                            }
                        }
                        OutlinedButton(onClick = {
                            TimePickerDialog(ctx, { _, h, m ->
                                val s = String.format(Locale.US, "%02d:%02d", h, m)
                                if (s !in times) times.add(s)
                            }, 8, 0, true).show()
                        }) { Text("إضافة وقت") }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = {
                val minutes = ((amountVal ?: 1.0) * (if (unitMinutes) 1 else 60)).toInt().coerceAtLeast(1)
                val start = when (type) {
                    Reminder.ONCE ->
                        if (afterVal != null && afterVal > 0)
                            System.currentTimeMillis() + (afterVal * 60_000).toLong()
                        else onceAt
                    Reminder.INTERVAL -> startAt
                    else -> 0L
                }
                onSave(message.trim(), type, minutes, times.sorted(), start)
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
