package com.example.reminders

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build

object Notifier {
    private const val PREFIX = "reminders"
    private val VIBRATION = longArrayOf(0, 300, 150, 300)

    // النغمة المختارة من المستخدم، وإلا نغمة التطبيق (res/raw/msg_tone.wav)
    fun soundUri(ctx: Context): Uri =
        Store.getSound(ctx)?.let { Uri.parse(it) }
            ?: Uri.parse("android.resource://${ctx.packageName}/${R.raw.msg_tone}")

    // إعدادات صوت القناة لا تتغير بعد إنشائها، فنستخدم قناة باسم مرتبط بالنغمة المختارة
    private fun channelId(ctx: Context): String =
        PREFIX + "_" + Integer.toHexString((Store.getSound(ctx) ?: "app").hashCode())

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val id = channelId(ctx)
        // احذف القنوات القديمة (نغمات سابقة)
        nm.notificationChannels
            .filter { it.id.startsWith(PREFIX) && it.id != id }
            .forEach { nm.deleteNotificationChannel(it.id) }
        if (nm.getNotificationChannel(id) != null) return
        val channel = NotificationChannel(id, "التذكيرات", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(
                soundUri(ctx),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            enableVibration(true)
            vibrationPattern = VIBRATION
        }
        nm.createNotificationChannel(channel)
    }

    fun show(ctx: Context, r: Reminder) {
        ensureChannel(ctx)
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(ctx, channelId(ctx))
        else
            Notification.Builder(ctx)
                .setSound(soundUri(ctx))
                .setVibrate(VIBRATION)
                .setPriority(Notification.PRIORITY_HIGH)

        val n = builder
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(r.title.ifBlank { "تذكير" })
            .setContentText(r.message)
            .setStyle(Notification.BigTextStyle().bigText(r.message))
            .setCategory(Notification.CATEGORY_REMINDER)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(r.id, n)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        val r = Store.load(ctx).firstOrNull { it.id == id } ?: return
        if (!r.enabled) return
        Notifier.show(ctx, r)
        if (r.type == Reminder.ONCE) {
            // مرة واحدة: بعد التنبيه نوقفه ولا نكرره
            Store.save(ctx, Store.load(ctx).map { if (it.id == r.id) it.copy(enabled = false) else it })
        } else {
            // جدولة التنبيه التالي
            Scheduler.schedule(ctx, r)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Scheduler.scheduleAll(ctx)
    }
}
