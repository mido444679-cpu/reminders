package com.example.reminders

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

object Notifier {
    const val CHANNEL = "reminders"

    fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "التذكيرات", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    fun show(ctx: Context, r: Reminder) {
        ensureChannel(ctx)
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(ctx, CHANNEL) else Notification.Builder(ctx)
        val n = builder
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("تذكير")
            .setContentText(r.message)
            .setStyle(Notification.BigTextStyle().bigText(r.message))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(r.id, n)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        val r = Store.load(ctx).firstOrNull { it.id == id } ?: return
        if (!r.enabled) return
        Notifier.show(ctx, r)
        // جدولة التنبيه التالي
        Scheduler.schedule(ctx, r)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Scheduler.scheduleAll(ctx)
    }
}
