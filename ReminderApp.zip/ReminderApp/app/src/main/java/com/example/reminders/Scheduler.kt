package com.example.reminders

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/**
 * كل الجدولة عن طريق AlarmManager: لا خدمة شغالة، ولا polling.
 * النظام نفسه يصحّي التطبيق وقت التنبيه فقط.
 */
object Scheduler {
    private const val MAX_SLOTS = 20 // أقصى عدد أوقات يومية للتذكير الواحد

    private fun pending(ctx: Context, r: Reminder, slot: Int, create: Boolean): PendingIntent? {
        val intent = Intent(ctx, AlarmReceiver::class.java).apply {
            putExtra("id", r.id)
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or
                (if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE)
        return PendingIntent.getBroadcast(ctx, r.id * 100 + slot, intent, flags)
    }

    fun cancel(ctx: Context, r: Reminder) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (slot in 0 until MAX_SLOTS) {
            pending(ctx, r, slot, create = false)?.let {
                am.cancel(it)
                it.cancel()
            }
        }
    }

    fun canScheduleExact(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return am.canScheduleExactAlarms()
    }

    fun schedule(ctx: Context, r: Reminder) {
        cancel(ctx, r)
        if (!r.enabled) return
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        if (r.type == Reminder.INTERVAL) {
            // فترات: توقيت غير دقيق بالثانية = أوفر للبطارية (النظام يجمّع التنبيهات)
            val at = System.currentTimeMillis() + r.intervalMinutes * 60_000L
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx, r, 0, true)!!)
        } else {
            r.times.take(MAX_SLOTS).forEachIndexed { slot, t ->
                val at = nextOccurrence(t)
                val pi = pending(ctx, r, slot, true)!!
                if (canScheduleExact(ctx)) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                }
            }
        }
    }

    fun scheduleAll(ctx: Context) {
        Store.load(ctx).forEach { schedule(ctx, it) }
    }

    private fun nextOccurrence(hhmm: String): Long {
        val (h, m) = hhmm.split(":").map { it.toInt() }
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h)
            set(Calendar.MINUTE, m)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }
}
