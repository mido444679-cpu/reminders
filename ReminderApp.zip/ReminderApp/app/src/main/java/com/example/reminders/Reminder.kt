package com.example.reminders

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * type = ONCE: مرة واحدة في startAt (تاريخ + وقت)
 * type = INTERVAL: يتكرر كل intervalMinutes دقيقة، ويبدأ من startAt (اختياري، 0 = من الآن)
 * type = DAILY: يتكرر يوميا في كل وقت من times (بصيغة HH:mm)
 */
data class Reminder(
    val id: Int,
    val message: String,
    val type: Int,
    val intervalMinutes: Int = 60,
    val times: List<String> = emptyList(),
    val enabled: Boolean = true,
    val startAt: Long = 0L,
    val title: String = ""
) {
    companion object {
        const val INTERVAL = 0
        const val DAILY = 1
        const val ONCE = 2
    }
}

data class Note(
    val id: Int,
    val title: String,
    val body: String,
    val updatedAt: Long
)

object Store {
    private const val PREFS = "reminders"
    private const val KEY_LIST = "list"
    private const val KEY_NEXT_ID = "next_id"

    private fun toArray(list: List<Reminder>): JSONArray {
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id)
                put("message", r.message)
                put("type", r.type)
                put("interval", r.intervalMinutes)
                put("times", JSONArray(r.times))
                put("enabled", r.enabled)
                put("startAt", r.startAt)
                put("title", r.title)
            })
        }
        return arr
    }

    private fun fromArray(arr: JSONArray): List<Reminder> =
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val t = o.getJSONArray("times")
            Reminder(
                id = o.getInt("id"),
                message = o.getString("message"),
                type = o.getInt("type"),
                intervalMinutes = o.getInt("interval"),
                times = (0 until t.length()).map { t.getString(it) },
                enabled = o.getBoolean("enabled"),
                startAt = o.optLong("startAt", 0L),
                title = o.optString("title", "")
            )
        }

    fun load(ctx: Context): List<Reminder> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LIST, null) ?: return emptyList()
        return fromArray(JSONArray(raw))
    }

    fun save(ctx: Context, list: List<Reminder>) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_LIST, toArray(list).toString()).apply()
    }

    // ---- النسخ الاحتياطي ----

    fun exportBackup(list: List<Reminder>, notes: List<Note>): String =
        JSONObject().apply {
            put("app", "reminders")
            put("version", 2)
            put("reminders", toArray(list))
            put("notes", notesToArray(notes))
        }.toString(2)

    // notes = null لو النسخة قديمة (قبل المذكرات): وقتها المذكرات الحالية ما بتتغيرش
    class Backup(val reminders: List<Reminder>, val notes: List<Note>?)

    // يرجع null لو الملف مش نسخة احتياطية صالحة
    fun parseBackup(raw: String): Backup? = try {
        val o = JSONObject(raw)
        Backup(
            fromArray(o.getJSONArray("reminders")),
            o.optJSONArray("notes")?.let { notesFromArray(it) }
        )
    } catch (e: Exception) {
        null
    }

    // ---- المذكرات ----

    private fun notesToArray(list: List<Note>): JSONArray {
        val arr = JSONArray()
        list.forEach { n ->
            arr.put(JSONObject().apply {
                put("id", n.id)
                put("title", n.title)
                put("body", n.body)
                put("updatedAt", n.updatedAt)
            })
        }
        return arr
    }

    private fun notesFromArray(arr: JSONArray): List<Note> =
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Note(
                id = o.getInt("id"),
                title = o.optString("title", ""),
                body = o.optString("body", ""),
                updatedAt = o.optLong("updatedAt", 0L)
            )
        }

    fun loadNotes(ctx: Context): List<Note> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString("notes", null) ?: return emptyList()
        return try { notesFromArray(JSONArray(raw)) } catch (e: Exception) { emptyList() }
    }

    fun saveNotes(ctx: Context, list: List<Note>) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString("notes", notesToArray(list).toString()).apply()
    }

    fun newNoteId(ctx: Context): Int {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val id = p.getInt("next_note_id", 1)
        p.edit().putInt("next_note_id", id + 1).apply()
        return id
    }

    fun ensureNextNoteIdAbove(ctx: Context, list: List<Note>) {
        val max = list.maxOfOrNull { it.id } ?: return
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (p.getInt("next_note_id", 1) <= max) p.edit().putInt("next_note_id", max + 1).apply()
    }

    // ---- المظهر: 0 تلقائي (حسب الجهاز)، 1 فاتح، 2 داكن ----
    fun getTheme(ctx: Context): Int =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("theme", 0)

    fun setTheme(ctx: Context, mode: Int) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt("theme", mode).apply()
    }

    // بعد الاسترجاع: نتأكد إن الأرقام الجديدة أكبر من أي رقم مسترجع
    fun ensureNextIdAbove(ctx: Context, list: List<Reminder>) {
        val max = list.maxOfOrNull { it.id } ?: return
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (p.getInt(KEY_NEXT_ID, 1) <= max) p.edit().putInt(KEY_NEXT_ID, max + 1).apply()
    }

    // النغمة المختارة (Uri كنص). null = نغمة التطبيق الأصلية
    fun getSound(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("sound", null)

    fun setSound(ctx: Context, uri: String?) {
        val e = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        if (uri == null) e.remove("sound") else e.putString("sound", uri)
        e.apply()
    }

    // الوضع الموثوق: منبه نظام (setAlarmClock) بيتخطى توفير البطارية، وبيظهر أيقونة منبه صغيرة
    fun isReliable(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("reliable", true)

    fun setReliable(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("reliable", on).apply()
    }

    fun newId(ctx: Context): Int {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val id = p.getInt(KEY_NEXT_ID, 1)
        p.edit().putInt(KEY_NEXT_ID, id + 1).apply()
        return id
    }
}
