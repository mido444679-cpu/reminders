package com.example.reminders

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * type = INTERVAL: يتكرر كل intervalMinutes دقيقة
 * type = DAILY: يتكرر يوميا في كل وقت من times (بصيغة HH:mm)
 */
data class Reminder(
    val id: Int,
    val message: String,
    val type: Int,
    val intervalMinutes: Int = 60,
    val times: List<String> = emptyList(),
    val enabled: Boolean = true
) {
    companion object {
        const val INTERVAL = 0
        const val DAILY = 1
    }
}

object Store {
    private const val PREFS = "reminders"
    private const val KEY_LIST = "list"
    private const val KEY_NEXT_ID = "next_id"

    fun load(ctx: Context): List<Reminder> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LIST, null) ?: return emptyList()
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val t = o.getJSONArray("times")
            Reminder(
                id = o.getInt("id"),
                message = o.getString("message"),
                type = o.getInt("type"),
                intervalMinutes = o.getInt("interval"),
                times = (0 until t.length()).map { t.getString(it) },
                enabled = o.getBoolean("enabled")
            )
        }
    }

    fun save(ctx: Context, list: List<Reminder>) {
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id)
                put("message", r.message)
                put("type", r.type)
                put("interval", r.intervalMinutes)
                put("times", JSONArray(r.times))
                put("enabled", r.enabled)
            })
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_LIST, arr.toString()).apply()
    }

    fun newId(ctx: Context): Int {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val id = p.getInt(KEY_NEXT_ID, 1)
        p.edit().putInt(KEY_NEXT_ID, id + 1).apply()
        return id
    }
}
