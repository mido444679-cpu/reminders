package com.example.reminders

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * type = ONCE: مرة واحدة في startAt (تاريخ + وقت)
 * type = INTERVAL: يتكرر كل intervalMinutes دقيقة، ويبدأ من startAt (اختياري، 0 = من الآن)
 * type = DAILY: يتكرر يوميا في كل وقت من times (بصيغة HH:mm)
 */
data class Reminder(
    val id: Int,
    val message: String,
    val type: Int,
    val intervalMinutes: Int = 60,
    val times: List<String> = emptyList(),
    val enabled: Boolean = true,
    val startAt: Long = 0L,
    val title: String = ""
) {
    companion object {
        const val INTERVAL = 0
        const val DAILY = 1
        const val ONCE = 2
    }
}

object Store {
    private const val PREFS = "reminders"
    private const val KEY_LIST = "list"
    private const val KEY_NEXT_ID = "next_id"

    private fun toArray(list: List<Reminder>): JSONArray {
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id)
                put("message", r.message)
                put("type", r.type)
                put("interval", r.intervalMinutes)
                put("times", JSONArray(r.times))
                put("enabled", r.enabled)
                put("startAt", r.startAt)
                put("title", r.title)
            })
        }
        return arr
    }

    private fun fromArray(arr: JSONArray): List<Reminder> =
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val t = o.getJSONArray("times")
            Reminder(
                id = o.getInt("id"),
                message = o.getString("message"),
                type = o.getInt("type"),
                intervalMinutes = o.getInt("interval"),
                times = (0 until t.length()).map { t.getString(it) },
                enabled = o.getBoolean("enabled"),
                startAt = o.optLong("startAt", 0L),
                title = o.optString("title", "")
            )
        }

    fun load(ctx: Context): List<Reminder> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LIST, null) ?: return emptyList()
        return fromArray(JSONArray(raw))
    }

    fun save(ctx: Context, list: List<Reminder>) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_LIST, toArray(list).toString()).apply()
    }

    // ---- النسخ الاحتياطي ----

    fun exportBackup(list: List<Reminder>): String =
        JSONObject().apply {
            put("app", "reminders")
            put("version", 1)
            put("reminders", toArray(list))
        }.toString(2)

    // يرجع null لو الملف مش نسخة احتياطية صالحة
    fun parseBackup(raw: String): List<Reminder>? = try {
        fromArray(JSONObject(raw).getJSONArray("reminders"))
    } catch (e: Exception) {
        null
    }

    // بعد الاسترجاع: نتأكد إن الأرقام الجديدة أكبر من أي رقم مسترجع
    fun ensureNextIdAbove(ctx: Context, list: List<Reminder>) {
        val max = list.maxOfOrNull { it.id } ?: return
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (p.getInt(KEY_NEXT_ID, 1) <= max) p.edit().putInt(KEY_NEXT_ID, max + 1).apply()
    }

    // النغمة المختارة (Uri كنص). null = نغمة التطبيق الأصلية
    fun getSound(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("sound", null)

    fun setSound(ctx: Context, uri: String?) {
        val e = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        if (uri == null) e.remove("sound") else e.putString("sound", uri)
        e.apply()
    }

    // الوضع الموثوق: منبه نظام (setAlarmClock) بيتخطى توفير البطارية، وبيظهر أيقونة منبه صغيرة
    fun isReliable(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("reliable", true)

    fun setReliable(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("reliable", on).apply()
    }

    fun newId(ctx: Context): Int {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val id = p.getInt(KEY_NEXT_ID, 1)
        p.edit().putInt(KEY_NEXT_ID, id + 1).apply()
        return id
    }
}
